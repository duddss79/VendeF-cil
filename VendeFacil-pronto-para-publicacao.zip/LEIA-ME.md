# VendeFácil — pacote para publicação web

## Conteúdo
- `index.html`: interface e política CSP via meta tag.
- `styles.css`: estilos locais.
- `app.js`: lógica local do app.

## Publicação recomendada: GitHub Pages
1. Peça a um responsável de confiança para ajudar com a conta se precisar. Não compartilhe senha, códigos de autenticação nem documentos em chats.
2. Crie um repositório público chamado `vendefacil` e envie estes três arquivos para a raiz. Lembre-se: o código-fonte e o conteúdo publicado ficarão públicos. Não inclua dados reais de clientes.
3. No repositório, abra Settings → Pages e configure a publicação a partir da branch principal (`main`) e da pasta `/ (root)`.
4. Quando o site estiver publicado, confirme que a URL começa com `https://` e, em Settings → Pages, ative `Enforce HTTPS` se a opção estiver disponível.
5. Teste o site em um navegador anônimo e no celular antes de divulgar.

Documentação oficial HTTPS: https://docs.github.com/pt/pages/getting-started-with-github-pages/securing-your-github-pages-site-with-https

## Privacidade e limites
- Não há backend nem chamadas de rede feitas pelo código do app; `connect-src 'none'` ajuda a bloquear conexões iniciadas pela página. Abrir WhatsApp é uma navegação explícita iniciada pelo usuário.
- O nome do negócio, segmento, tom e produtos ficam no `localStorage` deste navegador. Não são criptografados e podem ser acessados por scripts executados na mesma origem.
- Preços, mensagens e cálculos são mantidos na memória da página; ao fechar/recarregar, normalmente desaparecem. O texto que a pessoa envia ao WhatsApp passa a ser tratado pelo WhatsApp.
- “Apagar meus dados” remove apenas a chave `vf` do armazenamento local deste navegador e limpa os campos visíveis; não apaga mensagens já enviadas, cópias, histórico do WhatsApp ou logs da hospedagem.
- O provedor de hospedagem pode registrar dados técnicos de acesso. Consulte as políticas do provedor antes de publicar.
- O CSP está no HTML porque hospedagem estática como GitHub Pages não permite configurar cabeçalhos HTTP arbitrários. A diretiva `frame-ancestors` não funciona em meta CSP; proteção contra enquadramento depende de cabeçalho da hospedagem.
- Não use o app para guardar senhas, dados bancários ou informações pessoais de clientes.

## Verificações feitas neste pacote
- JavaScript e CSS separados do HTML para permitir uma política CSP com `script-src 'self'`.
- CSP limita conexões de rede da página, bloqueia plugins/objetos e restringe a origem de scripts.
- Abertura do WhatsApp usa link com `rel="noopener noreferrer"`.
- Calculadora esclarece quando preço e margem desejada são informados simultaneamente.

Esta revisão estática não é uma certificação de segurança nem substitui testes da versão publicada.
