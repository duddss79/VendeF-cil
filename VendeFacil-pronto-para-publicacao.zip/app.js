const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const el=(t,a={},...k)=>{const e=document.createElement(t);for(const x in a)e[x==='class'?'className':x]=a[x];k.flat().forEach(c=>e.append(c));return e};
const SEG={lanchonete:['Lanchonete ou restaurante','🍔','Faça seu pedido pelo WhatsApp'],barbearia:['Barbearia','✂️','Agende seu horário pelo WhatsApp'],manicure:['Manicure ou estética','💅','Agende seu horário pelo WhatsApp'],loja:['Pequena loja','🛍️','Chame no WhatsApp e garanta o seu'],autonomo:['Vendedor autônomo','📦','Chame no WhatsApp e faça seu pedido'],servicos:['Prestador de serviços','🔧','Chame no WhatsApp e peça seu orçamento']};
const DEF={nome:'',seg:'lanchonete',tom:'descontraido',prod:''};
let S={...DEF};
try{const d=JSON.parse(localStorage.getItem('vf'));if(d&&typeof d==='object')for(const k in S)if(typeof d[k]==='string')S[k]=d[k].slice(0,1000)}catch(e){}
if(!SEG[S.seg])S.seg=DEF.seg;
if(S.tom!=='formal')S.tom='descontraido';
const save=()=>{try{localStorage.setItem('vf',JSON.stringify(S));return true}catch(e){return false}};
const R=n=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const pc=n=>n.toLocaleString('pt-BR',{maximumFractionDigits:1})+'%';
const N=v=>{let s=String(v).trim();if(!/^(\d{1,3}(\.\d{3})+|\d+)(,\d{1,2})?$|^\d+\.\d{1,2}$/.test(s))return NaN;if(/,|^\d{1,3}(\.\d{3})+$/.test(s))s=s.replace(/\./g,'').replace(',','.');const n=Number(s);return Number.isFinite(n)&&n<=1e9?n:NaN};
const fim=s=>s?s.replace(/[.!?\s]+$/,'')+'.':'';
const hi=()=>S.tom==='formal'?'Olá!':'Oi!';
let tt;const toast=m=>{const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(tt);tt=setTimeout(()=>t.hidden=true,3200)};

function go(v){$$('main section').forEach(s=>s.hidden=s.id!=='v-'+v);$$('nav button').forEach(b=>b.setAttribute('aria-current',b.dataset.v===v?'page':'false'));scrollTo(0,0)}
$$('nav button').forEach(b=>b.addEventListener('click',()=>go(b.dataset.v)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));

const BR=/\[[^\]]+\]/;
async function copiar(ta){let ok=true;try{await navigator.clipboard.writeText(ta.value)}catch(e){ta.select();try{ok=document.execCommand('copy')}catch(_){ok=false}}
toast(!ok?'Não foi possível copiar. Segure o texto para copiar.':BR.test(ta.value)?'Copiado, mas ainda há trechos entre [colchetes] para preencher.':'Texto copiado.')}
function zap(ta){if(BR.test(ta.value))return toast('Preencha os trechos entre [colchetes] antes de enviar. Toque no texto para editar.');const a=el('a',{href:'https://wa.me/?text='+encodeURIComponent(ta.value),target:'_blank',rel:'noopener noreferrer'});a.hidden=true;document.body.append(a);a.click();a.remove()}
function card(l,x){const ta=el('textarea',{value:x,rows:x.split('\n').length+2});ta.setAttribute('aria-label',l+' (você pode editar)');
return el('div',{class:'card'},el('h2',{},l),el('p',{class:'mut'},'Você pode editar o texto antes de usar.'),ta,el('div',{class:'row'},el('button',{class:'btn alt',onclick:()=>copiar(ta)},'Copiar'),el('button',{class:'btn',onclick:()=>zap(ta)},'WhatsApp')))}

/* Divulgação */
function tipoUI(){const t=$('#p-tipo').value,b=$('#p-xbox');b.hidden=!(t==='pct'||t==='depor');$('#p-xl').textContent=t==='pct'?'Percentual de desconto (%)':'Preço antigo (R$)';$('#p-extra').value=''}
$('#p-tipo').addEventListener('change',tipoUI);
$('#p-go').addEventListener('click',()=>{
const p=$('#p-prod').value.trim(),pr=N($('#p-preco').value),t=$('#p-tipo').value,ex=N($('#p-extra').value),d=fim($('#p-det').value.trim()),o=$('#p-out'),e=$('#p-err');
const bad=m=>{e.textContent=m;o.replaceChildren()};e.textContent='';
if(!p)return bad('Digite o nome do produto ou serviço.');
if(!(pr>0))return bad('Digite o preço, por exemplo 12,50.');
if(t==='pct'&&!(ex>0&&ex<100))return bad('Digite um percentual de desconto entre 1 e 99.');
if(t==='depor'&&!(ex>pr))return bad('O preço antigo precisa ser maior que o preço novo.');
const g=SEG[S.seg],em=g[1],c=g[2],nm=S.nome?'\n'+S.nome:'';
const of={esp:`${p} por ${R(pr)}`,pct:`${p} com ${pc(ex)} de desconto, por ${R(pr)}`,depor:`${p}: de ${R(ex)} por ${R(pr)}`,novo:`Novidade: ${p} por ${R(pr)}`}[t];
o.replaceChildren(
card('Direta',`${em} Oferta especial!\n${of}.${d?'\n'+d:''}\n${c}!${nm}`),
card('Simpática',`${hi()}\n${em} ${of}.${d?'\n'+d:''}\n${c}.${nm}`),
card('Curta',`${em} ${of}. ${d?d+' ':''}${c}!${S.nome?' — '+S.nome:''}`))});

/* Respostas */
const FAQ={
horario:['Horário de funcionamento',(h,c)=>[`${h} Funcionamos de [dias da semana], das [abertura] às [fechamento].`,`${h} Obrigado por entrar em contato! Nosso atendimento é de [dias da semana], das [abertura] às [fechamento]. ${c}.`]],
preco:['Quanto custa?',(h,c)=>[`${h} O valor de [produto ou serviço] é [R$ valor].`,`${h} Obrigado pelo interesse! [Produto ou serviço] custa [R$ valor]. Se quiser, posso passar mais detalhes. ${c}.`]],
pagamento:['Formas de pagamento',(h,c)=>[`${h} Aceitamos [formas de pagamento].`,`${h} Você pode pagar com [formas de pagamento]. Qualquer dúvida, é só avisar. ${c}.`]],
entrega:['Faz entrega?',(h,c)=>[`${h} [Sim ou não] para entrega. Região: [bairros]. Taxa: [valor].`,`${h} Sobre entrega: [explique se entrega, em quais regiões e qual a taxa]. ${c}.`]],
agendar:['Quero marcar um horário',(h,c)=>[`${h} Me diga o serviço, o dia e o horário que prefere, que eu confirmo a disponibilidade.`,`${h} Vamos marcar! Para agendar, preciso saber: qual serviço, qual dia e qual horário você prefere. Vou conferir a agenda e já te respondo.`]],
cancelar:['Preciso remarcar ou cancelar',(h,c)=>[`${h} Sem problema! Me avise com [antecedência] para remarcarmos.`,`${h} Obrigado por avisar. Para remarcar ou cancelar, [explique como funciona]. Se quiser, já me diga um novo dia e horário.`]],
disp:['Ainda tem disponível?',(h,c)=>[`${h} Vou conferir e já te respondo.`,`${h} Obrigado pelo contato! Vou verificar a disponibilidade de [produto ou serviço] e já te aviso. ${c}.`]]};
for(const k in FAQ)$('#r-tipo').append(el('option',{value:k},FAQ[k][0]));
$('#r-go').addEventListener('click',()=>{const f=FAQ[$('#r-tipo').value][1](hi(),SEG[S.seg][2]);const sig=S.nome?'\n'+S.nome:'';
$('#r-out').replaceChildren(card('Resposta curta',f[0]+sig),card('Resposta completa',f[1]+sig))});

/* Calculadora */
$('#c-go').addEventListener('click',()=>{
const g=id=>$('#'+id).value.trim(),o=$('#c-out'),e=$('#c-err');e.textContent='';o.replaceChildren();
const bad=m=>{e.textContent=m};
for(const id of ['c-custo','c-desp','c-taxa','c-preco','c-marg','c-qtd'])if(g(id)!==''&&isNaN(N(g(id))))return bad('Use apenas números positivos, sem letras, até 1.000.000.000. Exemplo: 12,50.');
const num=(id,d)=>g(id)===''?d:N(g(id));
const custo=num('c-custo',NaN),desp=num('c-desp',0),taxa=num('c-taxa',0),preco=num('c-preco',NaN),marg=num('c-marg',NaN),qtd=num('c-qtd',1);
if(!(custo>=0))return bad('Digite o custo do produto, por exemplo 8,00.');
if(!(desp>=0))return bad('As outras despesas não podem ser negativas.');
if(!(taxa>=0&&taxa<100))return bad('A taxa sobre a venda deve ficar entre 0 e 99.');
if(!(Number.isInteger(qtd)&&qtd>=1&&qtd<=100000))return bad('A quantidade deve ser um número inteiro de 1 a 100.000.');
if(isNaN(preco)&&isNaN(marg))return bad('Digite o preço de venda ou a margem desejada.');
if(!isNaN(preco)&&!(preco>0))return bad('O preço de venda precisa ser maior que zero.');
if(!isNaN(marg)&&!(marg>=0&&marg<100))return bad('A margem desejada deve ficar entre 0 e 99.');
const base=custo+desp,den=m=>1-taxa/100-m/100;
let sug;
if(!isNaN(marg)){if(den(marg)<=0)return bad('Com essa taxa e essa margem não existe preço que feche a conta. Reduza a margem ou a taxa.');sug=base/den(marg);if(!(sug>0))return bad('Com custo e despesas zerados não dá para sugerir preço. Informe um valor maior que zero.')}
if(sug!==undefined){o.append(el('div',{class:'tag'},el('small',{},`Preço para ter ${pc(marg)} de margem`),el('strong',{},R(sug))));if(!isNaN(preco))o.append(el('p',{class:'mut'},'Você informou um preço de venda e uma margem desejada. O preço acima é a sugestão para essa margem; o lucro abaixo será calculado usando o preço de venda que você informou.'));}
 const P=isNaN(preco)?sug:preco,lu=P-base-P*taxa/100,mg=lu/P*100;
o.append(el('div',{class:'card'},el('h2',{},`Com o preço de ${R(P)}`),
...[['Faturamento (tudo que entra)',R(P*qtd)],['Custos, despesas e taxas',R((base+P*taxa/100)*qtd)],[lu>=0?'Lucro estimado':'Prejuízo estimado',R(Math.abs(lu*qtd))],['Margem de lucro',pc(mg)]].map(([a,b])=>el('div',{class:'line'},el('span',{},a),el('b',{},b))),
el('p',{class:'mt12'},lu>=0?`De cada ${R(100)} que entram, cerca de ${R(mg)} ficam como lucro.`:`Com esse preço você perde cerca de ${R(-mg)} a cada ${R(100)} vendidos.`),
el('p',{class:'mut'},'Faturamento é o total vendido. Lucro é o que sobra depois de pagar custo, despesas e taxas. Margem é o lucro dividido pelo faturamento.')));
const sim=[10,20,30,40].filter(m=>den(m)>0).map(m=>el('div',{class:'line'},el('span',{},`Margem de ${m}%`),el('b',{},`${R(base/den(m))} (lucro ${R(base/den(m)*m/100)})`)));
if(sim.length)o.append(el('div',{class:'card'},el('h2',{},'Simulações de preço'),el('p',{class:'mut'},'Preço de venda para cada margem, com lucro por unidade.'),...sim,
el('p',{class:'mut mt12'},'É uma estimativa com os números que você digitou. Não inclui impostos nem custos que ficaram de fora, e não garante vendas.')))});

/* Configurações */
for(const k in SEG)$('#s-seg').append(el('option',{value:k},SEG[k][0]));
function fill(){$('#s-nome').value=S.nome;$('#s-seg').value=S.seg;$('#s-tom').value=S.tom;$('#s-prod').value=S.prod;$('#nome').textContent=S.nome||'VendeFácil';
$('#dl').replaceChildren(...S.prod.split('\n').map(x=>x.trim()).filter(Boolean).slice(0,50).map(x=>el('option',{value:x})))}
$('#s-save').addEventListener('click',()=>{S.nome=$('#s-nome').value.trim().slice(0,60);S.seg=SEG[$('#s-seg').value]?$('#s-seg').value:DEF.seg;S.tom=$('#s-tom').value==='formal'?'formal':'descontraido';S.prod=$('#s-prod').value.slice(0,1000);
toast(save()?'Configurações salvas.':'Não foi possível salvar neste navegador.');fill()});
function limpaTela(){$$('#v-divulgar input,#v-calc input').forEach(i=>i.value='');['#p-out','#r-out','#c-out'].forEach(s=>$(s).replaceChildren());['#p-err','#c-err'].forEach(s=>$(s).textContent='');$('#p-tipo').value='esp';tipoUI()}
let armed=0;
$('#s-del').addEventListener('click',()=>{const b=$('#s-del');
if(!armed){armed=setTimeout(()=>{armed=0;b.textContent='Apagar meus dados'},5000);b.textContent='Toque de novo para confirmar';return}
clearTimeout(armed);armed=0;b.textContent='Apagar meus dados';let ok=true;try{localStorage.removeItem('vf');ok=localStorage.getItem('vf')===null}catch(e){ok=false}S={...DEF};fill();limpaTela();toast(ok?'Dados apagados deste aparelho.':'Não foi possível confirmar a exclusão. Apague os dados do site nas configurações do Chrome.')});

fill();tipoUI();go('inicio');
