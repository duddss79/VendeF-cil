# VendeFácil — resumo de privacidade

O VendeFácil gera textos e faz cálculos no navegador. O código desta versão não envia os campos preenchidos para um servidor nem usa analytics. Ao abrir o WhatsApp, o texto escolhido é encaminhado para esse serviço.

## O que fica salvo
Somente nome do negócio, segmento, estilo de comunicação e lista de produtos/serviços ficam salvos no armazenamento local (`localStorage`) do navegador. Esses dados não são criptografados; não use informações confidenciais. Preços, cálculos e mensagens geradas não são salvos deliberadamente pelo app.

## Exclusão
O botão “Apagar meus dados” remove as configurações locais do VendeFácil neste navegador e limpa os campos visíveis. Ele não remove mensagens já enviadas ao WhatsApp, textos copiados, dados de outros aplicativos, backups do navegador ou registros técnicos mantidos pela hospedagem.

## Hospedagem
O provedor pode manter registros técnicos de acesso. A política e o prazo de retenção dependem do serviço escolhido.

## Cuidados
Não informe nomes, telefones, conversas de clientes, senhas, dados bancários ou outras informações confidenciais. Use apenas informações comerciais necessárias.

Este documento descreve o comportamento previsto no código incluído neste pacote; confirme novamente após cada atualização e depois de publicar.
